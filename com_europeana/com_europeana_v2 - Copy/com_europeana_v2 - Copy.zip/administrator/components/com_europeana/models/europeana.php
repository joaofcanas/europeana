<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
// import the Joomla modellist library
jimport('joomla.application.component.modellist');
/**
 * EuropeanaList Model
 */
class EuropeanaModelEuropeana extends JModelList
{
    /**
     * Method to build an SQL query to load the list data.
     *
     * @return      string  An SQL query
     */
    protected function getListQuery()
    {
        $filter = JRequest::getVar('filter','0');
        // Create a new query object.           
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        // Select some fields
        $query->select('f.*, u.username, u.name');
        $query->from('#__europeana_files AS f');
        $query->leftJoin('#__users AS u ON f.user_id = u.id');
        $query->where('f.deleted = ' . $db->quote($filter));
        $query->order('f.datetime DESC');
        
        return $query;
    }
}