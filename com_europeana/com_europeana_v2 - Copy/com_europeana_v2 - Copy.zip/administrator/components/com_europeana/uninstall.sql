DROP TABLE IF EXISTS #__europeana_files;
