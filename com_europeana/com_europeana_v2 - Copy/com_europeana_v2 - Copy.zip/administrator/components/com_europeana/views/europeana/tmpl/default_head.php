<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
    <th width="5">
        <?php echo JText::_('COM_EUROPEANA_EUROPEANA_FILE_ID'); ?>
    </th>                
    <th>
        <?php echo JText::_('COM_EUROPEANA_EUROPEANA_NAME'); ?>
    </th>
    <th width="5">
        <?php echo JText::_('COM_EUROPEANA_EUROPEANA_USERNAME'); ?>
    </th>                
    <th>
        <?php echo JText::_('COM_EUROPEANA_EUROPEANA_FILENAME'); ?>
    </th>
    <th width="5">
        <?php echo JText::_('COM_EUROPEANA_EUROPEANA_DATETIME'); ?>
    </th>                
</tr>