<?php

defined('_JEXEC') or die('You do not have permission');
jimport('joomla.application.component.model');

class EuropeanaModelExport extends JModel {
    //put your code here
}
