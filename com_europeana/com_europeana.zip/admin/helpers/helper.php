<?php

defined('_JEXEC') or die('You do not have permission');

class EuropeanaHelper {
    
    public static function getCucu()
    {
        
    }
    
}
