<?php

defined('_JEXEC') or die('You do not have permission');
jimport('joomla.application.component.controller');

class EuropeanaControllerExport extends JController {
    
    public function edit(){
        
    }
    
    public function add() {
        
    }
    
    public function remove() {
        
    }
    
    public function cancel() {
        
    }
    
    public function save() {
        
    }
    
    public function apply() {
        
    }
    
    public function export() {
        
    }
}
