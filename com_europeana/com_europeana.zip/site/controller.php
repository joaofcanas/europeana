<?php

defined('_JEXEC') or die('You do not have permission');
jimport('joomla.application.component.controller');

class EuropeanaController extends JController {
}
