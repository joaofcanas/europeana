<?php
defined('_JEXEC') or die('Access denied');
jimport('joomla.application.component.controller');
class EuropeanaController extends JController {
    
    function display(){
        echo "I'm here without task!";
    }
    
    function export() {
        echo "Export";
    }
}